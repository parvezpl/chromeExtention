

// here we are receiving the message 
let nameData={
    AplicantName: "",
    fatherName: "",
    thana: ""
}


const fatherTitle=["पिता", "पुत्र", "पुत्री","a"," सी/ओ", "पति", "पत्नी", "पत्नी", "माता", "बेटा", "बेटी", "पति", "पत्नी", "बेटी", "C/O", "D/O", "S/O", "W/O", "H/O", "C/O", "D/O", "S/O"];


let windowsId = [];
chrome.runtime.onMessage.addListener(function(request) {
    console.log(request);
    newWindows(request)
    if (request.engen === "excelmanager") {
        dataArray = request.data;
        fatherTitle.forEach(title => {
            if (dataArray[3].includes(title)) {
                nameData.fatherName =  String(dataArray[3].split(title)[1].trim().split(" ")[0]); ;
                nameData.AplicantName = String(dataArray[3].split(title)[0].split(" ")[0]);
                nameData.thana=dataArray[1];
               
                // console.log(nameData.fatherName, nameData.fatherName.split(" ")[0]);
                sendSmsFunction("content",nameData)
            }
        });
    }
    if (request.engen === "excelmanagerWindowData") {
        console.log(request)
        if (request.isChecked) {
            windowsId.push(request.tabId)
        } else {
            windowsId = windowsId.filter(id => id !== request.tabId)
        }
        console.log(windowsId)
    }
});


let setTabid = true
let targetTabId = 0
function sendSmsFunction(isEngen, message) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {

        // if (setTabid) {
        //     targetTabId = tabs[0].id
        // }
        
        // if (isEngen === "content") {
        //     // console.log(targetTabId)
        //     chrome.tabs.sendMessage(targetTabId, { isEngen: "datasender", data: nameData })
        //     setTabid = false
        // }

        // setTabid = false


        windowsId.forEach(id => {
            chrome.tabs.sendMessage(id, { isEngen: "datasender", data: message })
        })


    })


}




function newWindows(message) {
    if (message.action === "openPopup") {
        sendSmsFunction()
        chrome.windows.create(
            {
                url: "newpopup.html", // URL of the page to open
                type: "popup", // Open as a popup window
                width: 400,
                height: 500,
                focused: true // Ensure the popup is focused initially
            },
            (createdWindow) => {
                // console.log("Popup window created:", createdWindow);
                // sendResponse({ status: "Popup created" });
            }
        );
        // return true; // Indicates asynchronous response
    }
}