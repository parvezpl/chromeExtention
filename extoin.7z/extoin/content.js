console.log("content.jss");
chrome.runtime.onMessage.addListener(function(request) {
    console.log(request);

    if (request.isEngen === "datasender") {
        let namefild = document.getElementsByName("ctl00$ContentPlaceHolder1$txtAccusedNameFirSearch")[0]
        let fatherNamefild = document.getElementsByName("ctl00$ContentPlaceHolder1$txtRelativeNameFirSearch")[0]
        let searchtbn = document.getElementsByName("ctl00$ContentPlaceHolder1$btnSearchFir")[0]
        // console.log(request.data);
        namefild.value = request.data.AplicantName
        fatherNamefild.value = request.data.fatherName
        searchtbn.click()
    }

});

// document.getElementsByName("ctl00$ContentPlaceHolder1$txtAccusedNameFirSearch")[0].value = "test";

